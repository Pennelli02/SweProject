package DomainModel;

public enum State {
    Booking_Confirmed,
    Checking_In,
    Checking_Out,
    Cancelled,
    Booking_Refunded,
    Accommodation_Cancelled,
}
