package DomainModel;

public enum Location {
    Sea,
    Mountain,
    ArtCity,
    Nothing
}
